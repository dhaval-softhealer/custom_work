# Copyright (C) Softhealer Technologies.
# Part of Softhealer Technologies.
# -*- coding: utf-8 -*-

{
    "name": "Repair customization",
    "author": "Softhealer Technologies",
    "website": "https://www.softhealer.com",
    "support": "support@softhealer.com",
    "category": "",
    "license": "OPL-1",
    "summary": "",
    "description": """.""",
    "version": "16.0.1",
    'depends': ['repair' , 'purchase'],
    "data": [
        'views/repair.xml',
    ],
    'installable': True,
}
