from . import on_product_template_created
from . import on_item_created
from . import on_price_updated
from . import on_partner_updated